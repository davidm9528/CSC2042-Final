#Inserts Persons
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Sheilakathryn', 'Temporal', '07735874296', '1987-06-11', 'Ulises', '07734833171');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Carol', 'Stollard', '07716549475', '1981-01-14', 'Georgena', '07853528159');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Hastie', 'Dagnall', '07861082835', '1990-06-02', 'Adelle', '07764002530');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Erl', 'Steel', '07809052802', '1983-05-04', 'Ransell', '07852013220');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Rodrique', 'Kenwin', '07736106428', '1982-06-13', 'Hugues', '07726622883');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Robby', 'Routh', '07814685381', '1990-05-29', 'Luciana', '07833298401');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Harri', 'Besemer', '07783581917', '1993-06-11', 'Hakim', '07758587056');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Thurstan', 'McCrow', '07899876847', '1991-09-25', 'Mattie', '07987268699');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Delmor', 'Holbury', '07797810530', '1986-02-16', 'Danika', '07741273941');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Liz', 'Roylance', '07884881044', '1983-08-09', 'Diane', '07808881128');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Grantham', 'Luckin', '07743902498', '1988-02-05', 'Kiri', '07767305403');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Korella', 'McPeeters', '07852043364', '1989-01-30', 'Madonna', '07821124662');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Brynna', 'Broxton', '07747196371', '1998-01-18', 'Isiahi', '07793567340');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Cristobal', 'Sperry', '07756834826', '1990-08-26', 'Alon', '07851344181');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Nealon', 'Wyldbore', '07856931672', '1989-01-26', 'Ana', '07782889079');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Neely', 'O''Gormley', '07814130414', '1997-03-05', 'Eveleen', '07805728488');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Kerrie', 'Grelik', '07843260837', '1983-01-04', 'Crichton', '07791250731');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Torrence', 'Thompsett', '07738730267', '1991-05-01', 'Gaven', '07701187100');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Earvin', 'Codeman', '07769082589', '1986-01-21', 'Alano', '07713696276');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Jelene', 'Hatter', '07856406393', '1993-04-20', 'Krispin', '07745687397');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Sully', 'Leggett', '07443441203', '1997-05-11', 'Valery', '07399963444');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Aristotle', 'Guilloux', '07652518254', '1997-04-11', 'Isis', '07823430571');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Hildagard', 'Arrow', '07064018852', '1997-12-24', 'Herbie', '07530300765');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Dona', 'Caudell', '07446368370', '1999-03-23', 'Elsbeth', '07158993278');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Lavinie', 'Blazej', '07585055229', '1998-10-14', 'Courtnay', '07869160122');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Guntar', 'Claxson', '07943598591', '1996-10-22', 'Bryn', '07585868187');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Meaghan', 'Hearty', '07045112610', '1996-12-30', 'Daryle', '07113491497');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Abrahan', 'Balmadier', '07060932672', '1996-11-13', 'Conroy', '07603967964');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Janot', 'Niblock', '07382464345', '1998-08-10', 'Lorenzo', '07975229663');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Elonore', 'Clarey', '07663944759', '1998-09-13', 'Angelia', '07119563070');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Ninette', 'Steanyng', '07192707919', '1999-03-29', 'Guillemette', '07715100772');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Misha', 'Binford', '07619568484', '1997-03-17', 'Brena', '07873375307');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Marni', 'Entres', '07401820098', '1996-02-19', 'Corty', '07771267543');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Tove', 'Deetlefs', '07305518157', '1997-12-23', 'Ede', '07268241578');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Tommie', 'Deverille', '07951084108', '1997-11-23', 'Dyana', '07554909115');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('James', 'Smoth', '07951009708', '1998-11-21', 'Davo', '07554412115');
insert into Person (FName, SName, ContactNumber, DoB, EmergencyContactName, EmergencyContactNumber) values ('Jessica', 'Cairns', '07959034108', '1996-01-16', 'Jillian', '07550019115');

#Inserts Tenants
INSERT INTO Tenant(PersonID) VALUES(1);
INSERT INTO Tenant(PersonID) VALUES(2);
INSERT INTO Tenant(PersonID) VALUES(3);
INSERT INTO Tenant(PersonID) VALUES(4);
INSERT INTO Tenant(PersonID) VALUES(5);
INSERT INTO Tenant(PersonID) VALUES(6);
INSERT INTO Tenant(PersonID) VALUES(7);
INSERT INTO Tenant(PersonID) VALUES(8);
INSERT INTO Tenant(PersonID) VALUES(9);
INSERT INTO Tenant(PersonID) VALUES(10);
INSERT INTO Tenant(PersonID) VALUES(21);
INSERT INTO Tenant(PersonID) VALUES(22);
INSERT INTO Tenant(PersonID) VALUES(23);
INSERT INTO Tenant(PersonID) VALUES(24);
INSERT INTO Tenant(PersonID) VALUES(25);
INSERT INTO Tenant(PersonID) VALUES(26);
INSERT INTO Tenant(PersonID) VALUES(27);
INSERT INTO Tenant(PersonID) VALUES(28);
INSERT INTO Tenant(PersonID) VALUES(29);
INSERT INTO Tenant(PersonID) VALUES(30);
INSERT INTO Tenant(PersonID) VALUES(31);
INSERT INTO Tenant(PersonID) VALUES(32);
INSERT INTO Tenant(PersonID) VALUES(33);
INSERT INTO Tenant(PersonID) VALUES(34);
INSERT INTO Tenant(PersonID) VALUES(35);
INSERT INTO Tenant(PersonID) VALUES(36);

#Inserts Employees
INSERT INTO Employee(PersonID, Salary) VALUES(11, 20000);
INSERT INTO Employee(PersonID, Salary) VALUES(12, 22500);
INSERT INTO Employee(PersonID, Salary) VALUES(13, 22600);
INSERT INTO Employee(PersonID, Salary) VALUES(14, 24800);
INSERT INTO Employee(PersonID, Salary) VALUES(15, 29000);
INSERT INTO Employee(PersonID, Salary) VALUES(16, 29125);
INSERT INTO Employee(PersonID, Salary) VALUES(17, 30000);
INSERT INTO Employee(PersonID, Salary) VALUES(18, 42000);
INSERT INTO Employee(PersonID, Salary) VALUES(19, 45675);
INSERT INTO Employee(PersonID, Salary) VALUES(20, 63250);
INSERT INTO Employee(PersonID, Salary) VALUES(37, 28000);

#Inserts Managers
INSERT INTO Manager(EmployeeID) VALUES(1);
INSERT INTO Manager(EmployeeID) VALUES(2);
INSERT INTO Manager(EmployeeID) VALUES(3);
INSERT INTO Manager(EmployeeID) VALUES(4);
INSERT INTO Manager(EmployeeID) VALUES(5);
INSERT INTO Manager(EmployeeID) VALUES(6);
INSERT INTO Manager(EmployeeID) VALUES(11);

#Inserts Technicians
INSERT INTO Technician(EmployeeID) VALUES(7);
INSERT INTO Technician(EmployeeID) VALUES(8);
INSERT INTO Technician(EmployeeID) VALUES(9);
INSERT INTO Technician(EmployeeID) VALUES(10);

#Inserts Skills
INSERT INTO Skill(SkillName) VALUES("carpentry");
INSERT INTO Skill(SkillName) VALUES("plumbing");
INSERT INTO Skill(SkillName) VALUES("electrical");

#Inserts TechnicianSkills
INSERT INTO TechnicianSkill(SkillID, TechnicianID) VALUES (1,1);
INSERT INTO TechnicianSkill(SkillID, TechnicianID) VALUES (2,2);
INSERT INTO TechnicianSkill(SkillID, TechnicianID) VALUES (3,3);
INSERT INTO TechnicianSkill(SkillID, TechnicianID) VALUES (1,3);

#Inserts Bank Accounts
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (1, 39283942, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (2, 39283944, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (3, 39283942, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (4, 39283933, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (5, 39283945, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (6, 39283944, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (7, 39283937, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (8, 39283941, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (9, 39283947, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (10, 39283944, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (11, 39283932, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (12, 39283941, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (13, 39283930, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (14, 39283944, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (15, 39283942, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (16, 39283940, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (17, 39283935, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (18, 39283947, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (19, 39283931, 400004);
INSERT INTO Bank_Account (PersonID, AccountNumber, SortCode) VALUES (20, 39283933, 400004);

#Inserts Buildings
INSERT INTO Building(BuildingNameOrNum, Street, Postcode) VALUES ("Ash 1", "Ash Ave", "BT9 5BW");
INSERT INTO Building(BuildingNameOrNum, Street, Postcode) VALUES ("Ash 2", "Ash Ave", "BT9 5BW");
INSERT INTO Building(BuildingNameOrNum, Street, Postcode) VALUES ("Oak 1", "Oak Cres", "BT9 5BW");
INSERT INTO Building(BuildingNameOrNum, Street, Postcode) VALUES ("Sycamore 1", "Sycamore St", "BT9 5BW");
INSERT INTO Building(BuildingNameOrNum, Street, Postcode) VALUES ("Sycamore 2", "Sycamore St", "BT9 5BW");
INSERT INTO `Building`(`BuildingNameorNum`,`Street`,`PostCode`) VALUES('72','Malone Avenue', 'BT9 6ER');
INSERT INTO `Building`(`BuildingNameorNum`,`Street`,`PostCode`) VALUES('10','Malone Road', 'BT7 1NP');

#Inserts Apartments
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (1,1,2,4,4,1500);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (2,1,1,2,1,1300);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (1,2,3,5,5,1550);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (2,2,3,1,1,750);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (1,3,2,1,1,500);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (2,3,2,1,1,500);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (3,3,2,1,1,500);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (1,4,5,4,2,1750);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (2,4,5,2,1,1200);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (1,5,4,2,1,1500);
INSERT INTO Apartment(ApartmentNo, BuildingID, ManagerID, NumBedrooms, NumBathrooms, TotalArea) VALUES (2,5,4,2,1,1400);
INSERT INTO `Apartment`(`ApartmentNo`,`NumBedrooms`,`NumBathrooms`,`TotalArea`,`BuildingID`,`ManagerID`) VALUES(2,4,2,300,6,7);
INSERT INTO `Apartment`(`ApartmentNo`,`NumBedrooms`,`NumBathrooms`,`TotalArea`,`BuildingID`,`ManagerID`) VALUES(1,1,1,200,6,7);
INSERT INTO `Apartment`(`ApartmentNo`,`NumBedrooms`,`NumBathrooms`,`TotalArea`,`BuildingID`,`ManagerID`) VALUES(1,1,1,225,7,7);

#Inserts office
INSERT INTO Office(ApartmentID, ManagerID) VALUES (4,1);
INSERT INTO Office(ApartmentID, ManagerID) VALUES (5,2);
INSERT INTO Office(ApartmentID, ManagerID) VALUES (6,3);
INSERT INTO Office(ApartmentID, ManagerID) VALUES (1,4);
INSERT INTO Office(ApartmentID, ManagerID) VALUES (2,5);
INSERT INTO Office(ApartmentID, ManagerID) VALUES (3,6);
INSERT INTO `Office`(`ApartmentID`,`ManagerID`) VALUES(14,7);

#Inserts leases
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (1,12,1,250,'2019-09-16');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (2,12,3,260,'2019-09-23');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (3,12,6,230,'2019-09-23');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (4,12,4,300,'2019-09-23');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (5,24,5,275,'2019-08-01');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (6,12,1,200,'2019-09-23');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (7,9,1,250,'2020-01-01');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (8,6,4,280,'2019-09-23');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (9,9,4,220,'2019-09-16');
INSERT INTO Lease(ApartmentID, Duration, ManagerID, Rent, StartDate) VALUES (10,9,2,220,'2019-09-16');
INSERT INTO `Lease`(`ApartmentID`,`ManagerID`,`StartDate`,`Duration`,`Rent`) VALUES(12,7,'2019-01-01',24,1000);
INSERT INTO `Lease`(`ApartmentID`,`ManagerID`,`StartDate`,`Duration`,`Rent`) VALUES(14,7,'2019-01-01',9,400);
INSERT INTO `Lease`(`ApartmentID`,`ManagerID`,`StartDate`,`Duration`,`Rent`) VALUES(13,7,'2019-04-01',12,400);

#Inserts TenantLeases
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (1,1);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (1,2);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (1,3);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (2,5);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (2,6);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (3,7);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (3,8);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (3,9);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (3,10);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (3,11); 
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (4,12);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (5,13);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (6,14);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (7,15);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (8,16);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (8,17);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (9,18);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (9,19);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (10,20);
INSERT INTO LeaseTenants(LeaseID, TenantID) VALUES (10,21);
INSERT INTO `LeaseTenants`(`LeaseID`,`TenantID`) VALUES(11,22);
INSERT INTO `LeaseTenants`(`LeaseID`,`TenantID`) VALUES(11,23);
INSERT INTO `LeaseTenants`(`LeaseID`,`TenantID`) VALUES(11,24);
INSERT INTO `LeaseTenants`(`LeaseID`,`TenantID`) VALUES(12,25);
INSERT INTO `LeaseTenants`(`LeaseID`,`TenantID`) VALUES(13,26);